Frontend
```sh
npm i

npm run dev
```

Backend (Python 3.9.0)
```sh
cd backend

py -3.9 -m venv venv

venv/Scripts/activate

pip install -r requirements.txt

python app.py
```